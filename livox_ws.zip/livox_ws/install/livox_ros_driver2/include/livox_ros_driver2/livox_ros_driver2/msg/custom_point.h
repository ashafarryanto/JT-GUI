// generated from rosidl_generator_c/resource/idl.h.em
// with input from livox_ros_driver2:msg/CustomPoint.idl
// generated code does not contain a copyright notice

#ifndef LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_H_
#define LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_H_

#include "livox_ros_driver2/msg/detail/custom_point__struct.h"
#include "livox_ros_driver2/msg/detail/custom_point__functions.h"
#include "livox_ros_driver2/msg/detail/custom_point__type_support.h"

#endif  // LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_H_
